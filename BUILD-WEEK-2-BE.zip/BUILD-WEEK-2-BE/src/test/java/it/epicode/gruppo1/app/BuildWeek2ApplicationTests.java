package it.epicode.gruppo1.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuildWeek2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
