package it.epicode.gruppo1.app.entities.enums;

public enum TipoRuolo {
	
	ROLE_USER,
	ROLE_ADMIN
	
}
