package it.epicode.gruppo1.app.exceptions;

public class PageException extends RuntimeException {

	public PageException(String message) {
		super(message);
	}
	
}
