package it.epicode.gruppo1.app.entities.enums;

public enum StatoFattura {

	PAGATA, 
	DA_PAGARE, 
	SCADUTA
	
}