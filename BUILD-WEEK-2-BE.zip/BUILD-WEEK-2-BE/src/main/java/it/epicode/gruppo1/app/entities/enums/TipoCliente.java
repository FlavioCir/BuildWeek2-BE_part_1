package it.epicode.gruppo1.app.entities.enums;

public enum TipoCliente {

	PA,
	SPA,
	SAS,
	SRL
	
}
